package Doll;

import java.time.LocalDate;

import Kid.Kid;
import Toy.Toy;




public class Doll extends Toy{
	
	enum Feeld{
		SOFT,
		HARD
	}
	
	
	private Feeld feeld;
	private int dirty;
	
	
	public Doll(String name, LocalDate puchaseDate, Kid kid, Feeld feeld) {
		super(name, puchaseDate, kid);
		this.feeld = feeld;
		this.dirty = 0;
	}
	
	private void dirtiness() {
		this.setDirty(1);
	}
	
	@Override
	public void play() {
		if(kid.getBirthDate().getYear()<0 || kid.getBirthDate().getYear()>4) {
			System.out.println("Sori cnat be to player");
		}
		else {
			if(this.broken()) {
				this.dirtiness();
				this.toString();
			}
			else 
				System.out.println("the Doll is broken");
		}
		
	}
	@Override
	public String toString() {
		return super.toString() + " Doll [feeld=" + feeld + ", dirty=" + dirty + "]";
	}
	
	public Feeld getFeeld() {
		return feeld;
	}
	public void setFeeld(Feeld feeld) {
		this.feeld = feeld;
	}
	public int getDirty() {
		return dirty;
	}
	public void setDirty(int dirty) {
		if(this.dirty>=0 && this.dirty<10)
			this.dirty += dirty;
	}

}
