package AblePlaye;

public interface AblePlaye {

	void play();

	boolean broken();
}
