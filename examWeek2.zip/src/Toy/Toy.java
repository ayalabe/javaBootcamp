package Toy;

import java.time.LocalDate;

import AblePlaye.AblePlaye;
import Kid.Kid;

public abstract class Toy implements AblePlaye{
	
	private int countSerialNumber = 0;
	private String name;
	private LocalDate puchaseDate;
	private int serialNumber;
	protected Kid kid;
	
	public Toy(String name, LocalDate puchaseDate, Kid kid) {
		this.name = name;
		this.puchaseDate = puchaseDate;
		this.serialNumber = countSerialNumber++;
		this.kid = kid;
	}

	
	
	public boolean broken() {
		if(this.getPuchaseDate().getYear()>=1)
			return false;
		return true;
		
	}

	public int getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}

	public LocalDate getPuchaseDate() {
		return puchaseDate;
	}

	public void setPuchaseDate(LocalDate puchaseDate) {
		this.puchaseDate = puchaseDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
