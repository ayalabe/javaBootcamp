package ElectricToy;

import java.time.LocalDate;

import Kid.Kid;
import Toy.Toy;

public class ElectricToy extends Toy{
	
	private int batteries;

	public ElectricToy(String name, LocalDate puchaseDate, Kid kid) {
		super(name, puchaseDate, kid);
		this.batteries = 0;
	}

	
	@Override
	public void play() {
		if(kid.getBirthDate().getYear()<0 || kid.getBirthDate().getYear()>4) {
			System.out.println("Sori cnat be to player");
		}
		else {
			if(this.batteries>=0 || this.batteries<=3) {
				if(this.broken()) {
					this.decBattery();
					this.toString();
				}
				else
					System.out.println("the Doll is broken");
			}
			else 
				System.out.println("the battary is lower");
		}
		
	}
	
	@Override
	public String toString() {
		return super.toString() + " ElectricToy [batteries=" + batteries + "]";
	}


	private void decBattery() {
		if(this.batteries>=0 || this.batteries<=3) 
			this.batteries--;
	}


	public int getBatteries() {
		return batteries;
	}


	public void setBatteries(int batteries) {
		this.batteries += batteries;
	}


	
}
