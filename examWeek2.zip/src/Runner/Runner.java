package Runner;

import java.time.LocalDate;

import AblePlaye.AblePlaye;
import Doll.Doll;
import ElectricToy.ElectricToy;
import Kid.Kid;

public class Runner {

	public static void main(String[] args) {
		
		LocalDate date = LocalDate.of(2017, 1, 13);  
		Kid kid = new Kid("Ayala", date);
		
		AblePlaye toy[] = new AblePlaye[4];
		
		toy[0] = new Doll("barbi", date, kid, null);
		toy[1] = new Doll("buba", date, kid, null);
		
		toy[2] = new ElectricToy("Car", date, kid);
		toy[3] = new ElectricToy("bus", date, kid);
		
		for (AblePlaye ablePlaye : toy) {
			toy.play();
		}

	}

}
